CREATE DATABASE decodelabs;
-- Sample queries
SELECT * FROM sales;
SELECT COUNT(*) AS total_orders FROM sales;
SELECT SUM(TotalPrice) AS revenue FROM sales;
SELECT AVG(TotalPrice) AS avg_order FROM sales;
SELECT Product, SUM(TotalPrice) revenue FROM sales GROUP BY Product ORDER BY revenue DESC;
SELECT OrderStatus, COUNT(*) FROM sales GROUP BY OrderStatus;
SELECT * FROM sales WHERE TotalPrice>1000 ORDER BY TotalPrice DESC;
SELECT MONTH(Date) m, SUM(TotalPrice) revenue FROM sales GROUP BY MONTH(Date);
SELECT Product, AVG(UnitPrice) avg_price FROM sales GROUP BY Product;
SELECT Product, SUM(Quantity) qty FROM sales GROUP BY Product HAVING SUM(Quantity)>10;
