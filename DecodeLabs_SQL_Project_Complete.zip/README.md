# DecodeLabs Data Analytics Project 3

SQL Data Analysis project based on the provided dataset.

## Contents
- solution.sql
- Project_Report.docx

Skills: SELECT, WHERE, ORDER BY, GROUP BY, COUNT, SUM, AVG, HAVING.
